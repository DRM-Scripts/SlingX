<?php

function HTTP_CODE($URL){
	
	$HTTP_REQUEST = curl_init();

	curl_setopt($HTTP_REQUEST, CURLOPT_URL, $URL);
	curl_setopt($HTTP_REQUEST, CURLOPT_HEADER, true);
	curl_setopt($HTTP_REQUEST, CURLOPT_NOBODY, true);
	curl_setopt($HTTP_REQUEST, CURLOPT_RETURNTRANSFER, true);
	
	curl_exec($HTTP_REQUEST);
	
	$HTTP_RESPONCE = curl_getinfo($HTTP_REQUEST, CURLINFO_HTTP_CODE);
	curl_close($HTTP_REQUEST);

	return $HTTP_RESPONCE;
	
}

function GET_SERVER_UPTIME() {
	
	$UPTIME_FILE = file_get_contents('/proc/uptime');
	
	preg_match('/(.*?)\s(.*?)\\n/', $UPTIME_FILE, $UPTIME_OUTPUT);
	
	$DAYS = floor( $UPTIME_OUTPUT[1] / 86400);
	$HOURS = floor( $UPTIME_OUTPUT[2] / 86400);
	
	return $DAYS.'D : '.$HOURS.'H';
	
}

function GET_CORE_COUNT() {
	
    $CMD = "uname";
    $OPERATING_SYSTEM = strtolower(trim(shell_exec($CMD)));
 
    switch($OPERATING_SYSTEM) {
       case('linux'):
          $CMD = "cat /proc/cpuinfo | grep processor | wc -l";
          break;
       case('freebsd'):
          $CMD = "sysctl -a | grep 'hw.ncpu' | cut -d ':' -f2";
          break;
       default:
          unset($CMD);
    }
 
    if ($CMD != '') {
		
       $CPU_CORES = intval(trim(shell_exec($CMD)));
	   
    }
    
    return empty($CPU_CORES) ? 1 : $CPU_CORES;
    
}

function GET_SERVER_LOAD($CORES = 2, $INTERVAL = 1) {
	
	$SYSTEM_LOAD	= sys_getloadavg();
	$INTERVAL		= $INTERVAL >= 1 && 3 <= $INTERVAL ? $INTERVAL : 1;
	$LOAD			= $SYSTEM_LOAD[$INTERVAL];
	
	return round(($LOAD * 100) / $CORES,2).'%';
	
}


function GET_DRM_PROCCESSED(){

    exec("pgrep -u mini_cs | wc -l 2>&1", $rOutput, $rRet);

    return intval($rOutput[0]);

}

function GET_BANDWIDTH_USAGE() {
   
    $int="enp5s0f0";
    
    $rx[] = @file_get_contents("/sys/class/net/$int/statistics/rx_bytes");
    $tx[] = @file_get_contents("/sys/class/net/$int/statistics/tx_bytes");
    sleep(1);
    $rx[] = @file_get_contents("/sys/class/net/$int/statistics/rx_bytes");
    $tx[] = @file_get_contents("/sys/class/net/$int/statistics/tx_bytes");
    
    $tbps = (int) $tx[1] - (int) $tx[0];
    $rbps = (int) $rx[1] - (int) $rx[0];
    
    $round_rx = round($rbps/1000024, 2).' Mbps';
    $round_tx = round($tbps/1000024, 2).' Mbps';
    

    return [$round_rx, $round_tx];

}


function GET_SIZE_UNITS($bytes) {

        if ($bytes >= 1073741824) {
			
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
			
        }elseif ($bytes >= 1048576) {
			
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
			
        } elseif ($bytes >= 1024) {
			
		$bytes = number_format($bytes / 1024, 2) . ' KB';
		
        } elseif ($bytes > 1) {
			
            $bytes = $bytes . ' bytes';
			
        } elseif ($bytes == 1) {
			
            $bytes = $bytes . ' byte';
			
        } else {
			
            $bytes = '0 bytes';
			
        }

        return $bytes;
}

?>